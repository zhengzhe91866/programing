#pragma once

#include <string>
#include <vector>
using namespace std;

//���@�ӨϥΪ̪��Ҧ���ơA�B�i�H�ק�
class Account {
	/*friend ostream& operator<<(ostream& output, Account ac) {
		output << ac.get_account() << endl;
		output << ac.get_pin() << endl;
		output << ac.get_a_balance() << endl;
		output << ac.get_t_balance() << endl;
		return output;
	}*/
public:
	using size_type = int;
	using value_type = double;

	//constructor
	Account() 
		: account_number(0), pin(0), available_balance(0), total_balance(0) {
	}
	Account(const int an, const int p, const double ab, const double tb)
		: account_number(an), pin(p), available_balance(ab), total_balance(tb) {
	}

	//setting balance
	void increase(const double& number)
	{
		total_balance += number;
	}
	void decrease(const double& number)
	{
		available_balance -= number;
		total_balance -= number;
	}

	//set functions
	void set_account(const string& line) {
		account_number = stoi(line);
		//cout << "Account: " << account_number << endl;
	}
	void set_pin(const string& line) {
		pin = stoi(line);
		//cout << "Pin: " << pin << endl;
	}
	void set_a_balance(const string& line) {
		available_balance = stod(line);
		//cout << "Available_balance: " << available_balance << endl;
	}
	void set_t_balance(const string& line) {
		total_balance = stod(line);
		//cout << "Total_balance: " << total_balance << endl;
	}

	//get functions
	size_type get_account() {
		return account_number;
	}
	size_type get_pin() {
		return pin;
	}
	value_type get_a_balance() {
		return available_balance;
	}
	value_type get_t_balance() {
		return total_balance;
	}

private:
	size_type account_number;
	size_type pin;
	value_type available_balance;
	value_type total_balance;
};