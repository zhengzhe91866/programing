#include <iostream>
#include <fstream>
#include <iomanip>

#include "Balance.h"
#include "Deposit.h"
#include "Withdrawal.h"

void loadAccountInfo(Database& accounts);                   //Ū��
void loadCashInfo(Database& accounts);

void saveAccountInfo(Database& accounts);                   //�g��
void saveCashInfo(Database& accounts);

int inputAnInteger(int begin, int end);                     //���H�e�x�F��

void signIn(Database &accounts);                            //�n�J
void mainMenu(Database &accounts);                          //�D���(�h��Lclass��)

Cash Database::cash = Cash();

int main() {
    cout << fixed << setprecision(2);
    Database accounts;
    
    loadAccountInfo(accounts);
    loadCashInfo(accounts);

    signIn(accounts);
}

void loadAccountInfo(Database &accounts) {
    //�@�L�����A�N�O�@��Ū��
    ifstream inMemberFile("Account Info.txt", ios::in);
    if (!inMemberFile)
    {
        cout << "File could not be opened" << endl;
        system("pause");
        exit(1);
    }

    Account buffer;
    //��Ū�쪺�ɮץ��memberDetails
    while (!inMemberFile.eof()) {
        string line;
        getline(inMemberFile, line);
        buffer.set_account(line);

        getline(inMemberFile, line);
        buffer.set_pin(line);

        getline(inMemberFile, line);
        buffer.set_a_balance(line);

        getline(inMemberFile, line);
        buffer.set_t_balance(line);

        accounts.push_back(buffer);

        /*cout << "Account " << accounts.num_accounts() << ":\n";
        cout << accounts.get_data()[accounts.num_accounts() - 1] << endl;*/
    }

    //�H������
    inMemberFile.close();
}
void loadCashInfo(Database& accounts) {
    //�@�L�����A�N�O�@��Ū��
    ifstream inMemberFile("Cash Info.txt", ios::in);
    if (!inMemberFile)
    {
        cout << "File could not be opened" << endl;
        system("pause");
        exit(1);
    }

    //��Ū�쪺�ɮץ��memberDetails
    while (!inMemberFile.eof()) {
        string line;
        getline(inMemberFile, line);
        accounts.cash.dollars[0] = stoi(line);

        getline(inMemberFile, line);
        accounts.cash.dollars[1] = stoi(line);

        getline(inMemberFile, line);
        accounts.cash.dollars[2] = stoi(line);

        getline(inMemberFile, line);
        accounts.cash.dollars[3] = stoi(line);

        getline(inMemberFile, line);
        accounts.cash.dollars[4] = stoi(line);
    }

    //�H������
    inMemberFile.close();
}

int inputAnInteger(int begin, int end) {
    //�کȨϥΪ̵��ڶÿ�J
    //�ҥH�N...

    //���Φr��s 
    string c;
    getline(cin, c, '\n');

    if (c[0] == NULL)
        return inputAnInteger(begin, end);

    //��J����]�t�ť� 
    for (unsigned int i = 0; i < c.size(); i++) {
        if (c[i] == ' ')
            return -1;
    }

    //��J��int�̤j�O�X��� 
    int n = end;
    unsigned int size = 0;
    if (n == 0)
        size = 1;
    while (n >= 1) {
        size++;
        if (n == 1)
            break;
        n /= 10;
    }

    //�p�G�W�L�N���ޥ� 
    if (c.size() > size) {
        return -1;
    }

    //��X�Ʀr�O�h�� 
    int sum = 0;
    for (int i = 0; i < c.size(); i++) {
        int pow = 1;
        for (int k = 0; k < i; k++)
            pow *= 10;
        sum += (c[c.size() - 1 - i] - 48) * pow;
    }

    //�b�d��~�N���~ 
    if (sum < begin || sum > end) {
        return -1;
    }

    return sum;
}

void signIn(Database& accounts) {
    while (true) {
        cout << "Welcome!" << endl << endl;

        int now_account_number;
        int now_pin;

        cout << "Please enter your account number: ";
        cin >> now_account_number;
        cout << "\nEnter your PIN: ";
        cin >> now_pin;

        if (accounts.illegal(now_account_number, now_pin)) { //�b�����s�b
            cout << "\nSorry, unrecognized email or password.\n\n";
        }
        else {
            mainMenu(accounts);
        }
    }
}
void mainMenu(Database& accounts) {
    while (true) {
        cout << "\nMain menu:\n";
        cout << "1 - View my balance\n"; //Balance
        cout << "2 - Withdraw cash\n";   //Withdrawal
        cout << "3 - Deposit funds\n";   //Deposit
        cout << "4 - Exit\n\n";

        int choice;

        do {
            cout << "Enter a choice: ";
        } while ((choice = inputAnInteger(1, 4)) == -1);

        Database* data = nullptr;

        switch (choice)
        {
        case 1:
            data = new Balance(accounts.get_data(), accounts.the_user());
            break;

        case 2:
            data = new Withdrawal(accounts.get_data(), accounts.the_user());
            break;

        case 3:
            data = new Deposit(accounts.get_data(), accounts.the_user());
            break;

        case 4:
            saveAccountInfo(accounts);
            saveCashInfo(accounts);
            cout << "\nExiting the system...\n\n";
            cout << "Thank you! Goodbye!\n\n";
            return;

        default:
            cout << "Input Error!\n\n";
            system("pause");
            break;
        }

        data->message();
        delete data;
    }
}

void saveAccountInfo(Database& accounts) {
    ofstream outMemberFile("Account Info.txt", ios::out);
    if (!outMemberFile)
    {
        cout << "File could not be opened" << endl;
        system("pause");
        exit(1);
    }

    //���ɮ׼g�i�h
    for (int i = 0; i < accounts.num_accounts(); i++) {
        if (i > 0)
            outMemberFile << '\n';
        outMemberFile << accounts.get_data()[i].get_account() << endl;
        outMemberFile << accounts.get_data()[i].get_pin() << endl;
        outMemberFile << accounts.get_data()[i].get_a_balance() << endl;
        outMemberFile << accounts.get_data()[i].get_t_balance();
    }

    //�H������
    outMemberFile.close();
}
void saveCashInfo(Database& accounts) {
    ofstream outMemberFile("Cash Info.txt", ios::out);
    if (!outMemberFile)
    {
        cout << "File could not be opened" << endl;
        system("pause");
        exit(1);
    }

    //���ɮ׼g�i�h
    for (int i = 0; i < 5; i++) {
        if (i != 0)
            outMemberFile << endl;
        outMemberFile << accounts.cash.dollars[i];
    }

    //�H������
    outMemberFile.close();
}