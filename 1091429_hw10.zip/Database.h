#pragma once

#include "Account.h"

class Cash {
public:
    Cash() {
    }

    double dollars[5];
};

//�ʸ˩Ҧ��ϥΪ̸��
class Database {
public:
    using ScaryVal = vector<Account>;
    using ScaryRef = vector<Account>&;
    using size_type = int;
    using value_type = double;
    using const_size = const size_type;
    using const_value = const value_type;
    using const_size_ref = const size_type&;
    using const_value_ref = const value_type&;

    Database() : myData(atm_accounts), user(-1) {
    }

    Database(ScaryRef accounts, const_size_ref account_number)
        : myData(accounts), user(account_number) {
    }

    void push_back(const Account& ac) {
        myData.push_back(ac);
    }

    ScaryRef get_data() {
        return myData;
    }

    size_type num_accounts() {
        return myData.size();
    }

    size_type the_user() {
        return user;
    }

    bool illegal(const_size_ref account_number, const_size_ref pin) {
        if (myData.size() == 0)
            return true;

        for (int i = 0; i < myData.size(); i++) {
            if ((myData[i].get_account() == account_number) && (myData[i].get_pin() == pin)) {
                user = i;
                return false;
            }
        }
        return true;
    }

    //�o��function�Τ���
    virtual void message() {
        cout << "�A���b�o��\n";
    }

    static Cash cash;
protected:
    size_type user; //���e�ϥΪ�
    ScaryRef myData;
    ScaryVal atm_accounts; //�b����Ʈw
    
    size_type inputAnInteger(const_size_ref begin, const_size_ref end) {
        //�کȨϥΪ̵��ڶÿ�J
        //�ҥH�N...

        //���Φr��s 
        string c;
        getline(cin, c, '\n');

        if (c[0] == NULL)
            return inputAnInteger(begin, end);

        //��J����]�t�ť� 
        for (unsigned int i = 0; i < c.size(); i++) {
            if (c[i] == ' ')
                return -1;
        }

        //��J��int�̤j�O�X��� 
        int n = end;
        unsigned int size = 0;
        if (n == 0)
            size = 1;
        while (n >= 1) {
            size++;
            if (n == 1)
                break;
            n /= 10;
        }

        //�p�G�W�L�N���ޥ� 
        if (c.size() > size) {
            return -1;
        }

        //��X�Ʀr�O�h�� 
        int sum = 0;
        for (int i = 0; i < c.size(); i++) {
            int pow = 1;
            for (int k = 0; k < i; k++)
                pow *= 10;
            sum += (c[c.size() - 1 - i] - 48) * pow;
        }

        //�b�d��~�N���~ 
        if (sum < begin || sum > end) {
            return -1;
        }

        return sum;
    }
};