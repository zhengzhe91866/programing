#pragma once

#include "Database.h"

class Balance : public Database {
public:
	Balance(ScaryRef accounts, const_size account_number)
		: Database(accounts, account_number) {
	}
	
	void message() {
		cout << "\nBalance Information:\n";
		cout << " - Available Balance: $" << myData[user].get_a_balance() << endl;
		cout << " - Total Balance :    $" << myData[user].get_t_balance() << endl;
	}
};