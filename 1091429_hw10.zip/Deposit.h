#pragma once

#include "Database.h"

class Deposit : public Database {
public:
	Deposit(ScaryRef accounts, const_size accountNumber)
        : Database(accounts, accountNumber) {
    }

	void message() {
        cout << "\nPlease enter a deposit amount in CENTS (or 0 to cancel): ";
        double money;
        cin >> money;
        if (money == 0)
            return;

        money /= 100;

        myData[user].increase(money);

        cout << "\nPlease insert a deposit envelope containing $" << money << " in the deposit slot.\n\n";
        cout << "Your envelope has been received.\n";
        cout << "Note: The money deposited will not be avilable until \nwe verify the amount of any enclosed cash, and any enclosed checks clear.\n";
	}
};