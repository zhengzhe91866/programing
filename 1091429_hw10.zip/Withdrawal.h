#pragma once

#include "Database.h"

class Withdrawal : public Database {
public:
    Withdrawal(ScaryRef accounts, const_size account_number)
        : Database(accounts, account_number) {
    }

	void message() {
        double cash_[6] = { 0.0, 20.0, 40.0, 60.0, 100.0, 200.0 }; //�i���������B
        cout << "withdrawal options:\n";
        cout << "1 - $20\n";
        cout << "2 - $40\n";
        cout << "3 - $60\n";
        cout << "4 - $100\n";
        cout << "5 - $200\n";
        cout << "6 - Cancel transaction\n\n";

        int choice;

        while (true) {
            cout << "choose a withdrawal option (1-6): ";
            if ((choice = inputAnInteger(1, 6)) != -1){
                if (choice == 6)
                    break;
                else if (myData[user].get_a_balance() - cash_[choice] < 0)
                    cout << "�A�S������h����\n";
                else if (cash.dollars[choice - 1] < 1)
                    cout << "ATM�S���o�� ($" << cash_[choice] << ") ���B�{�I\n";
                else {
                    myData[user].decrease(cash_[choice]);
                    --cash.dollars[choice - 1];
                    cout << "\nPlease take your cash fraom the cash dispenser.\n";
                    break;
                }
            }
        }
	}
};